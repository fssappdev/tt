

#' Unimportant DBI methods
#'
#' @name DBI-methods
#' @keywords internal
NULL

#' DBI classes
#'
#' @name DBI-classes
#' @keywords internal
NULL
